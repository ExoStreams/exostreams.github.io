#forthelulz

complete detailed tutorial here 

http://www.desinerd.co.in/python-create-kodi-video-addon-youtube-search/


